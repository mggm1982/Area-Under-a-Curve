#include <iostream>
#include <string>
#include <cmath>
#include <stdexcept>
#include <cctype>
#include <iomanip>
using namespace std;

const double PI = acos(-1.0);

// Mathematical Expression Evaluator
class Calculator {
    string s;
    int pos;
    double x;

    void skipSpaces() {
        while (pos < s.size() && isspace(s[pos]))
            pos++;
    }

    bool match(char c) {
        skipSpaces();
        if (pos < s.size() && s[pos] == c) {
            pos++;
            return true;
        }
        return false;
    }

    double expression() {
        double v = term();

        while (true) {
            if (match('+'))
                v += term();
            else if (match('-'))
                v -= term();
            else
                break;
        }
        return v;
    }

    double term() {
        double v = unary();

        while (true) {
            if (match('*'))
                v *= unary();
            else if (match('/')) {
                double d = unary();
                if (d == 0)
                    throw runtime_error("Division by zero");
                v /= d;
            }
            else
                break;
        }
        return v;
    }

    double unary() {
        if (match('+')) return unary();
        if (match('-')) return -unary();
        return power();
    }

    double power() {
        double v = primary();
        if (match('^'))
            v = pow(v, unary());
        return v;
    }

    double primary() {
        skipSpaces();

        if (match('(')) {
            double v = expression();
            if (!match(')'))
                throw runtime_error("Missing closing bracket");
            return v;
        }

        // Read numbers
        if (pos < s.size() &&
            (isdigit(s[pos]) || s[pos] == '.')) {
            size_t len;
            double v = stod(s.substr(pos), &len);
            pos += len;
            return v;
        }

        // Read variable or function name
        if (pos < s.size() && isalpha(s[pos])) {
            string name;

            while (pos < s.size() &&
                   isalpha(s[pos])) {
                name += tolower(s[pos++]);
            }

            if (name == "x") return x;
            if (name == "pi") return PI;
            if (name == "e") return exp(1.0);

            if (!match('('))
                throw runtime_error(
                    "Function must have parentheses");

            double a = expression();

            if (!match(')'))
                throw runtime_error("Missing closing bracket");

            if (name == "sin") return sin(a);
            if (name == "cos") return cos(a);
            if (name == "tan") return tan(a);
            if (name == "exp") return exp(a);
            if (name == "log" || name == "ln") {
                if (a <= 0)
                    throw runtime_error("Invalid logarithm");
                return log(a);
            }
            if (name == "sqrt") {
                if (a < 0)
                    throw runtime_error("Invalid square root");
                return sqrt(a);
            }
            if (name == "abs") return fabs(a);

            throw runtime_error("Unknown function: " + name);
        }

        throw runtime_error("Invalid mathematical expression");
    }

public:
    Calculator(string equation) {
        s = equation;
    }

    double evaluate(double value) {
        x = value;
        pos = 0;

        double result = expression();

        skipSpaces();

        if (pos != s.size())
            throw runtime_error("Invalid expression");

        if (!isfinite(result))
            throw runtime_error("Undefined function value");

        return result;
    }
};

// Midpoint Rule
double midpoint(Calculator &f, double a,
                double b, int n, bool geometric) {
    double h = (b - a) / n;
    double sum = 0;

    for (int i = 0; i < n; i++) {
        double x = a + (i + 0.5) * h;
        double y = f.evaluate(x);

        if (geometric) y = fabs(y);

        sum += y;
    }

    return sum * h;
}

// Trapezoidal Rule
double trapezoidal(Calculator &f, double a,
                   double b, int n, bool geometric) {
    double h = (b - a) / n;

    double first = f.evaluate(a);
    double last = f.evaluate(b);

    if (geometric) {
        first = fabs(first);
        last = fabs(last);
    }

    double sum = first + last;

    for (int i = 1; i < n; i++) {
        double y = f.evaluate(a + i * h);

        if (geometric) y = fabs(y);

        sum += 2 * y;
    }

    return (h / 2) * sum;
}

// Simpson's 1/3 Rule
double simpson(Calculator &f, double a,
               double b, int n, bool geometric) {
    double h = (b - a) / n;

    double first = f.evaluate(a);
    double last = f.evaluate(b);

    if (geometric) {
        first = fabs(first);
        last = fabs(last);
    }

    double sum = first + last;

    for (int i = 1; i < n; i++) {
        double y = f.evaluate(a + i * h);

        if (geometric) y = fabs(y);

        if (i % 2 == 0)
            sum += 2 * y;
        else
            sum += 4 * y;
    }

    return (h / 3) * sum;
}

int main() {
    try {
        string equation;
        double a, b;
        int n;

        cout << "====================================\n";
        cout << "   AREA UNDER CURVE CALCULATOR\n";
        cout << "   Using Numerical Integration\n";
        cout << "====================================\n";

        cout << "\nEnter the function f(x): ";
        getline(cin, equation);

        cout << "Enter lower limit (a): ";
        cin >> a;

        cout << "Enter upper limit (b): ";
        cin >> b;

        cout << "Enter number of intervals: ";
        cin >> n;

        if (a >= b)
            throw runtime_error(
                "Upper limit must be greater than lower limit");

        if (n <= 0)
            throw runtime_error(
                "Number of intervals must be positive");

        // Simpson's rule requires an even number
        if (n % 2 != 0) {
            n++;
            cout << "\nIntervals adjusted to " << n
                 << " for Simpson's rule.\n";
        }

        Calculator f(equation);

        // Check function at the limits and midpoint
        f.evaluate(a);
        f.evaluate((a + b) / 2);
        f.evaluate(b);

        cout << fixed << setprecision(8);

        cout << "\n========== RESULTS ==========\n";

        cout << "\n1. SIGNED DEFINITE INTEGRAL\n";

        cout << "Midpoint Rule     : "
             << midpoint(f, a, b, n, false) << endl;

        cout << "Trapezoidal Rule  : "
             << trapezoidal(f, a, b, n, false) << endl;

        cout << "Simpson's Rule    : "
             << simpson(f, a, b, n, false) << endl;

        cout << "\n2. APPROXIMATE GEOMETRIC AREA\n";

        cout << "Midpoint Rule     : "
             << midpoint(f, a, b, n, true) << endl;

        cout << "Trapezoidal Rule  : "
             << trapezoidal(f, a, b, n, true) << endl;

        cout << "Simpson's Rule    : "
             << simpson(f, a, b, n, true) << endl;

        cout << "\n=============================\n";
        cout << "Calculation completed!\n";

    }
    catch (exception &e) {
        cout << "\nERROR: " << e.what() << endl;
    }

    return 0;
}